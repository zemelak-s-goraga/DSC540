# DSC540-T301_2245_1 Data Preparation

Assignment Week 3 & 4;

Author: Zemelak Goraga;

Date: 4/6/2024

# Activity 3.01


```python
# Step 1: Load necessary libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
```


```python
# Step 2: Read in the Boston housing dataset
housing_data = pd.read_csv('Boston_housing.csv')
```


```python
# Step 3: Check the first 10 records and find the total number of records
print("First 10 records:")
print(housing_data.head(10))
print("\nTotal number of records:", len(housing_data))
```

    First 10 records:
          CRIM    ZN  INDUS  CHAS    NOX     RM    AGE     DIS  RAD  TAX  PTRATIO  \
    0  0.00632  18.0   2.31     0  0.538  6.575   65.2  4.0900    1  296     15.3   
    1  0.02731   0.0   7.07     0  0.469  6.421   78.9  4.9671    2  242     17.8   
    2  0.02729   0.0   7.07     0  0.469  7.185   61.1  4.9671    2  242     17.8   
    3  0.03237   0.0   2.18     0  0.458  6.998   45.8  6.0622    3  222     18.7   
    4  0.06905   0.0   2.18     0  0.458  7.147   54.2  6.0622    3  222     18.7   
    5  0.02985   0.0   2.18     0  0.458  6.430   58.7  6.0622    3  222     18.7   
    6  0.08829  12.5   7.87     0  0.524  6.012   66.6  5.5605    5  311     15.2   
    7  0.14455  12.5   7.87     0  0.524  6.172   96.1  5.9505    5  311     15.2   
    8  0.21124  12.5   7.87     0  0.524  5.631  100.0  6.0821    5  311     15.2   
    9  0.17004  12.5   7.87     0  0.524  6.004   85.9  6.5921    5  311     15.2   
    
            B  LSTAT  PRICE  
    0  396.90   4.98   24.0  
    1  396.90   9.14   21.6  
    2  392.83   4.03   34.7  
    3  394.63   2.94   33.4  
    4  396.90   5.33   36.2  
    5  394.12   5.21   28.7  
    6  395.60  12.43   22.9  
    7  396.90  19.15   27.1  
    8  386.63  29.93   16.5  
    9  386.71  17.10   18.9  
    
    Total number of records: 506
    


```python
# Step 4: Create a smaller DataFrame excluding specified columns
smaller_df = housing_data.drop(columns=['CHAS', 'NOX', 'B', 'LSTAT'])
smaller_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CRIM</th>
      <th>ZN</th>
      <th>INDUS</th>
      <th>RM</th>
      <th>AGE</th>
      <th>DIS</th>
      <th>RAD</th>
      <th>TAX</th>
      <th>PTRATIO</th>
      <th>PRICE</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.00632</td>
      <td>18.0</td>
      <td>2.31</td>
      <td>6.575</td>
      <td>65.2</td>
      <td>4.0900</td>
      <td>1</td>
      <td>296</td>
      <td>15.3</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.02731</td>
      <td>0.0</td>
      <td>7.07</td>
      <td>6.421</td>
      <td>78.9</td>
      <td>4.9671</td>
      <td>2</td>
      <td>242</td>
      <td>17.8</td>
      <td>21.6</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.02729</td>
      <td>0.0</td>
      <td>7.07</td>
      <td>7.185</td>
      <td>61.1</td>
      <td>4.9671</td>
      <td>2</td>
      <td>242</td>
      <td>17.8</td>
      <td>34.7</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.03237</td>
      <td>0.0</td>
      <td>2.18</td>
      <td>6.998</td>
      <td>45.8</td>
      <td>6.0622</td>
      <td>3</td>
      <td>222</td>
      <td>18.7</td>
      <td>33.4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.06905</td>
      <td>0.0</td>
      <td>2.18</td>
      <td>7.147</td>
      <td>54.2</td>
      <td>6.0622</td>
      <td>3</td>
      <td>222</td>
      <td>18.7</td>
      <td>36.2</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>501</th>
      <td>0.06263</td>
      <td>0.0</td>
      <td>11.93</td>
      <td>6.593</td>
      <td>69.1</td>
      <td>2.4786</td>
      <td>1</td>
      <td>273</td>
      <td>21.0</td>
      <td>22.4</td>
    </tr>
    <tr>
      <th>502</th>
      <td>0.04527</td>
      <td>0.0</td>
      <td>11.93</td>
      <td>6.120</td>
      <td>76.7</td>
      <td>2.2875</td>
      <td>1</td>
      <td>273</td>
      <td>21.0</td>
      <td>20.6</td>
    </tr>
    <tr>
      <th>503</th>
      <td>0.06076</td>
      <td>0.0</td>
      <td>11.93</td>
      <td>6.976</td>
      <td>91.0</td>
      <td>2.1675</td>
      <td>1</td>
      <td>273</td>
      <td>21.0</td>
      <td>23.9</td>
    </tr>
    <tr>
      <th>504</th>
      <td>0.10959</td>
      <td>0.0</td>
      <td>11.93</td>
      <td>6.794</td>
      <td>89.3</td>
      <td>2.3889</td>
      <td>1</td>
      <td>273</td>
      <td>21.0</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>505</th>
      <td>0.04741</td>
      <td>0.0</td>
      <td>11.93</td>
      <td>6.030</td>
      <td>80.8</td>
      <td>2.5050</td>
      <td>1</td>
      <td>273</td>
      <td>21.0</td>
      <td>11.9</td>
    </tr>
  </tbody>
</table>
<p>506 rows × 10 columns</p>
</div>




```python
# Step 5: Check the last seven records of the new DataFrame
print("\nLast seven records of the new DataFrame:")
print(smaller_df.tail(7))
```

    
    Last seven records of the new DataFrame:
            CRIM   ZN  INDUS     RM   AGE     DIS  RAD  TAX  PTRATIO  PRICE
    499  0.17783  0.0   9.69  5.569  73.5  2.3999    6  391     19.2   17.5
    500  0.22438  0.0   9.69  6.027  79.7  2.4982    6  391     19.2   16.8
    501  0.06263  0.0  11.93  6.593  69.1  2.4786    1  273     21.0   22.4
    502  0.04527  0.0  11.93  6.120  76.7  2.2875    1  273     21.0   20.6
    503  0.06076  0.0  11.93  6.976  91.0  2.1675    1  273     21.0   23.9
    504  0.10959  0.0  11.93  6.794  89.3  2.3889    1  273     21.0   22.0
    505  0.04741  0.0  11.93  6.030  80.8  2.5050    1  273     21.0   11.9
    


```python
# Step 6: Plot histograms of all variables in the new DataFrame
smaller_df.hist(figsize=(12, 10))
plt.tight_layout()
plt.show()
```


    
![png](output_7_0.png)
    



```python
# Step 7: Plot histograms of all variables using a for loop
for column in smaller_df.columns:
    plt.hist(smaller_df[column], bins=20)
    plt.title(f'Histogram of {column}')
    plt.xlabel(column)
    plt.ylabel('Frequency')
    plt.show()

```


    
![png](output_8_0.png)
    



    
![png](output_8_1.png)
    



    
![png](output_8_2.png)
    



    
![png](output_8_3.png)
    



    
![png](output_8_4.png)
    



    
![png](output_8_5.png)
    



    
![png](output_8_6.png)
    



    
![png](output_8_7.png)
    



    
![png](output_8_8.png)
    



    
![png](output_8_9.png)
    



```python
# Step 8: Create a scatter plot of crime rate versus price
plt.scatter(housing_data['CRIM'], housing_data['PRICE'])
plt.title('Crime Rate vs Price')
plt.xlabel('Crime Rate')
plt.ylabel('Price')
plt.show()
```


    
![png](output_9_0.png)
    



```python
# Step 9: Plot log10(crime) versus price
plt.scatter(np.log10(housing_data['CRIM']), housing_data['PRICE'])
plt.title('Log10(Crime Rate) vs Price')
plt.xlabel('Log10(Crime Rate)')
plt.ylabel('Price')
plt.show()
```


    
![png](output_10_0.png)
    



```python
# Step 10: Calculate and print some useful statistics
mean_rooms_per_dwelling = smaller_df['RM'].mean()
median_age = smaller_df['AGE'].median()
mean_distance_to_employment_centers = smaller_df['DIS'].mean()
percentage_low_price = (housing_data['PRICE'] < 20).mean() * 100

print("\nMean Rooms per Dwelling:", mean_rooms_per_dwelling)
print("Median Age:", median_age)
print("Mean Distance to Employment Centers:", mean_distance_to_employment_centers)
print("Percentage of Houses with Low Price (< $20,000):", percentage_low_price)

```

    
    Mean Rooms per Dwelling: 6.284634387351787
    Median Age: 77.5
    Mean Distance to Employment Centers: 3.795042687747034
    Percentage of Houses with Low Price (< $20,000): 41.50197628458498
    

# Discussion Activity 3.01


The primary objective of this analysis is to explore the Boston housing dataset and extract meaningful insights regarding the factors affecting housing prices. 

Specifically, the aims are:

Investigate the distribution of different features in the dataset.
Identify correlations between variables, particularly with respect to housing prices.
Calculate descriptive statistics to understand the central tendencies and variability of key features.
Explore the impact of crime rate on property prices.
Assess the proportion of houses with prices below $20,000.



I begin by loading the dataset into a pandas DataFrame and conducting preliminary data inspection. This involves checking the first few records, the data types of variables, and identifying any missing values. Subsequently, I performed data wrangling by excluding certain columns as specified in the problem statement.

Following data preprocessing, I visualized the distribution of variables through histograms and explore pairwise relationships using scatter plots. I then calculate descriptive statistics such as mean rooms per dwelling, median age, mean distances to employment centers, and the percentage of houses with low prices.



The analysis reveals several key findings. Firstly, the distribution of housing prices exhibits a right-skewed pattern, indicating that a majority of properties have lower prices. Secondly, there exists a strong positive correlation between the number of rooms per dwelling and property prices, suggesting that larger houses tend to be more expensive. Thirdly, the scatter plot depicting crime rate versus price illustrates a negative relationship, indicating that areas with higher crime rates tend to have lower property values. Finally, the calculated statistics provide insights into the average characteristics of houses in the Boston area.

# Activity 4.01


```python
# Step 1: Load the necessary libraries
import pandas as pd
import matplotlib.pyplot as plt
```


```python
# Step 2: Read the adult income dataset

income_data = pd.read_csv('adult_income_dataset.csv')
income_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>39</th>
      <th>State-gov</th>
      <th>77516</th>
      <th>Bachelors</th>
      <th>13</th>
      <th>Never-married</th>
      <th>Adm-clerical</th>
      <th>Not-in-family</th>
      <th>Male</th>
      <th>2174</th>
      <th>0</th>
      <th>40</th>
      <th>United-States</th>
      <th>&lt;=50K</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>50</td>
      <td>Self-emp-not-inc</td>
      <td>83311</td>
      <td>Bachelors</td>
      <td>13</td>
      <td>Married-civ-spouse</td>
      <td>Exec-managerial</td>
      <td>Husband</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>13</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
    <tr>
      <th>1</th>
      <td>38</td>
      <td>Private</td>
      <td>215646</td>
      <td>HS-grad</td>
      <td>9</td>
      <td>Divorced</td>
      <td>Handlers-cleaners</td>
      <td>Not-in-family</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
    <tr>
      <th>2</th>
      <td>53</td>
      <td>Private</td>
      <td>234721</td>
      <td>11th</td>
      <td>7</td>
      <td>Married-civ-spouse</td>
      <td>Handlers-cleaners</td>
      <td>Husband</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
    <tr>
      <th>3</th>
      <td>28</td>
      <td>Private</td>
      <td>338409</td>
      <td>Bachelors</td>
      <td>13</td>
      <td>Married-civ-spouse</td>
      <td>Prof-specialty</td>
      <td>Wife</td>
      <td>Female</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>Cuba</td>
      <td>&lt;=50K</td>
    </tr>
    <tr>
      <th>4</th>
      <td>37</td>
      <td>Private</td>
      <td>284582</td>
      <td>Masters</td>
      <td>14</td>
      <td>Married-civ-spouse</td>
      <td>Exec-managerial</td>
      <td>Wife</td>
      <td>Female</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Step 3: Create a script that will read a text file line by line
def read_file_line_by_line(file_path):
    with open(file_path, 'r') as file:
        for line in file:
            print(line)
```


```python
names = []
with open('adult_income_names.txt','r') as f:
    for line in f:
        f.readline()
        var=line.split(":")[0]
        names.append(var)
names
```




    ['age',
     'workclass',
     'fnlwgt',
     'education',
     'education-num',
     'marital-status',
     'occupation',
     'relationship',
     'sex',
     'capital-gain',
     'capital-loss',
     'hours-per-week',
     'native-country']




```python
names.append('income')
```


```python
income_data = pd.read_csv("adult_income_dataset.csv",names=names)
income_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>workclass</th>
      <th>fnlwgt</th>
      <th>education</th>
      <th>education-num</th>
      <th>marital-status</th>
      <th>occupation</th>
      <th>relationship</th>
      <th>sex</th>
      <th>capital-gain</th>
      <th>capital-loss</th>
      <th>hours-per-week</th>
      <th>native-country</th>
      <th>income</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>39</td>
      <td>State-gov</td>
      <td>77516</td>
      <td>Bachelors</td>
      <td>13</td>
      <td>Never-married</td>
      <td>Adm-clerical</td>
      <td>Not-in-family</td>
      <td>Male</td>
      <td>2174</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
    <tr>
      <th>1</th>
      <td>50</td>
      <td>Self-emp-not-inc</td>
      <td>83311</td>
      <td>Bachelors</td>
      <td>13</td>
      <td>Married-civ-spouse</td>
      <td>Exec-managerial</td>
      <td>Husband</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>13</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
    <tr>
      <th>2</th>
      <td>38</td>
      <td>Private</td>
      <td>215646</td>
      <td>HS-grad</td>
      <td>9</td>
      <td>Divorced</td>
      <td>Handlers-cleaners</td>
      <td>Not-in-family</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
    <tr>
      <th>3</th>
      <td>53</td>
      <td>Private</td>
      <td>234721</td>
      <td>11th</td>
      <td>7</td>
      <td>Married-civ-spouse</td>
      <td>Handlers-cleaners</td>
      <td>Husband</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
    <tr>
      <th>4</th>
      <td>28</td>
      <td>Private</td>
      <td>338409</td>
      <td>Bachelors</td>
      <td>13</td>
      <td>Married-civ-spouse</td>
      <td>Prof-specialty</td>
      <td>Wife</td>
      <td>Female</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>Cuba</td>
      <td>&lt;=50K</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Create a copy of the DataFrame

# Read the CSV file into a DataFrame
income_data = pd.read_csv("adult_income_dataset.csv", names=names)

# Create a copy
income_data_headed = income_data.copy()

```


```python
income_data_headed.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>workclass</th>
      <th>fnlwgt</th>
      <th>education</th>
      <th>education-num</th>
      <th>marital-status</th>
      <th>occupation</th>
      <th>relationship</th>
      <th>sex</th>
      <th>capital-gain</th>
      <th>capital-loss</th>
      <th>hours-per-week</th>
      <th>native-country</th>
      <th>income</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>39</td>
      <td>State-gov</td>
      <td>77516</td>
      <td>Bachelors</td>
      <td>13</td>
      <td>Never-married</td>
      <td>Adm-clerical</td>
      <td>Not-in-family</td>
      <td>Male</td>
      <td>2174</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
    <tr>
      <th>1</th>
      <td>50</td>
      <td>Self-emp-not-inc</td>
      <td>83311</td>
      <td>Bachelors</td>
      <td>13</td>
      <td>Married-civ-spouse</td>
      <td>Exec-managerial</td>
      <td>Husband</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>13</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
    <tr>
      <th>2</th>
      <td>38</td>
      <td>Private</td>
      <td>215646</td>
      <td>HS-grad</td>
      <td>9</td>
      <td>Divorced</td>
      <td>Handlers-cleaners</td>
      <td>Not-in-family</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
    <tr>
      <th>3</th>
      <td>53</td>
      <td>Private</td>
      <td>234721</td>
      <td>11th</td>
      <td>7</td>
      <td>Married-civ-spouse</td>
      <td>Handlers-cleaners</td>
      <td>Husband</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
    <tr>
      <th>4</th>
      <td>28</td>
      <td>Private</td>
      <td>338409</td>
      <td>Bachelors</td>
      <td>13</td>
      <td>Married-civ-spouse</td>
      <td>Prof-specialty</td>
      <td>Wife</td>
      <td>Female</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>Cuba</td>
      <td>&lt;=50K</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Step 5: Find the missing values
missing_values = income_data.isnull().sum()
print("Missing Values:")
print(missing_values)
```

    Missing Values:
    age               0
    workclass         0
    fnlwgt            0
    education         0
    education-num     0
    marital-status    0
    occupation        0
    relationship      0
    sex               0
    capital-gain      0
    capital-loss      0
    hours-per-week    0
    native-country    0
    income            0
    dtype: int64
    


```python
# Step 6: Create a DataFrame with only age, education, and occupation by using subsetting
subset_data = income_data[['age', 'education', 'occupation']]
subset_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>education</th>
      <th>occupation</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>39</td>
      <td>Bachelors</td>
      <td>Adm-clerical</td>
    </tr>
    <tr>
      <th>1</th>
      <td>50</td>
      <td>Bachelors</td>
      <td>Exec-managerial</td>
    </tr>
    <tr>
      <th>2</th>
      <td>38</td>
      <td>HS-grad</td>
      <td>Handlers-cleaners</td>
    </tr>
    <tr>
      <th>3</th>
      <td>53</td>
      <td>11th</td>
      <td>Handlers-cleaners</td>
    </tr>
    <tr>
      <th>4</th>
      <td>28</td>
      <td>Bachelors</td>
      <td>Prof-specialty</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>32556</th>
      <td>27</td>
      <td>Assoc-acdm</td>
      <td>Tech-support</td>
    </tr>
    <tr>
      <th>32557</th>
      <td>40</td>
      <td>HS-grad</td>
      <td>Machine-op-inspct</td>
    </tr>
    <tr>
      <th>32558</th>
      <td>58</td>
      <td>HS-grad</td>
      <td>Adm-clerical</td>
    </tr>
    <tr>
      <th>32559</th>
      <td>22</td>
      <td>HS-grad</td>
      <td>Adm-clerical</td>
    </tr>
    <tr>
      <th>32560</th>
      <td>52</td>
      <td>HS-grad</td>
      <td>Exec-managerial</td>
    </tr>
  </tbody>
</table>
<p>32561 rows × 3 columns</p>
</div>




```python
# Step 7: Plot a histogram of age with a bin size of 20
plt.hist(income_data['age'], bins=20)
plt.title('Histogram of Age')
plt.xlabel('Age')
plt.ylabel('Frequency')
plt.show()
```


    
![png](output_25_0.png)
    



```python
# Step 8: Create a function to strip the whitespace characters
def strip_whitespace(x):
    if isinstance(x, str):
        return x.strip()
    else:
        return x
```


```python
# Step 9: Use the apply method to apply this function to all the columns with string values
income_data = income_data.applymap(strip_whitespace)
```


```python
# Step 10: Find the number of people who are aged between 30 and 50

import pandas as pd

# convert the 'age' column to integers
income_data['age'] = income_data['age'].astype(int)

# Filter the DataFrame based on age
people_between_30_50 = income_data[(income_data['age'] >= 30) & (income_data['age'] <= 50)]

# Get the number of people aged between 30 and 50
num_people_between_30_50 = len(people_between_30_50)
print("Number of people aged between 30 and 50:", num_people_between_30_50)

```

    Number of people aged between 30 and 50: 16390
    


```python
# Step 11: Group the records based on age and education to find how the mean age is distributed
age_education_mean = income_data.groupby(['age', 'education']).mean()
age_education_mean

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>fnlwgt</th>
      <th>education-num</th>
      <th>capital-gain</th>
      <th>capital-loss</th>
      <th>hours-per-week</th>
    </tr>
    <tr>
      <th>age</th>
      <th>education</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">17</th>
      <th>10th</th>
      <td>187111.630435</td>
      <td>6.0</td>
      <td>266.659420</td>
      <td>46.434783</td>
      <td>21.543478</td>
    </tr>
    <tr>
      <th>11th</th>
      <td>188696.555556</td>
      <td>7.0</td>
      <td>30.411111</td>
      <td>36.911111</td>
      <td>19.927778</td>
    </tr>
    <tr>
      <th>12th</th>
      <td>178750.702703</td>
      <td>8.0</td>
      <td>0.000000</td>
      <td>46.513514</td>
      <td>20.189189</td>
    </tr>
    <tr>
      <th>5th-6th</th>
      <td>270942.000000</td>
      <td>3.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>48.000000</td>
    </tr>
    <tr>
      <th>7th-8th</th>
      <td>127804.000000</td>
      <td>4.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>31.000000</td>
    </tr>
    <tr>
      <th>...</th>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th rowspan="5" valign="top">90</th>
      <th>Bachelors</th>
      <td>165312.333333</td>
      <td>13.0</td>
      <td>2327.000000</td>
      <td>0.000000</td>
      <td>31.666667</td>
    </tr>
    <tr>
      <th>HS-grad</th>
      <td>132201.285714</td>
      <td>9.0</td>
      <td>1394.142857</td>
      <td>468.714286</td>
      <td>37.428571</td>
    </tr>
    <tr>
      <th>Masters</th>
      <td>150378.250000</td>
      <td>14.0</td>
      <td>5012.750000</td>
      <td>0.000000</td>
      <td>47.500000</td>
    </tr>
    <tr>
      <th>Prof-school</th>
      <td>87372.000000</td>
      <td>15.0</td>
      <td>20051.000000</td>
      <td>0.000000</td>
      <td>72.000000</td>
    </tr>
    <tr>
      <th>Some-college</th>
      <td>153924.333333</td>
      <td>10.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>32.833333</td>
    </tr>
  </tbody>
</table>
<p>965 rows × 5 columns</p>
</div>




```python

```


```python
# Step 12: Group by occupation and show the summary statistics of age

# Remove rows where the occupation is "?"
income_data_cleaned = income_data[income_data['occupation'] != "?"]

# Group by occupation and show the summary statistics of age
occupation_summary_stats = income_data_cleaned.groupby('occupation')['age'].describe()

# Check if there are any occupations with data beyond the 75th percentile
if '75%' in occupation_summary_stats:
    highest_percentile_profession = occupation_summary_stats[occupation_summary_stats['75%'] == occupation_summary_stats['75%'].max()].index[0]
    print("Profession with the largest share of the workforce above the 75th percentile:", highest_percentile_profession)
else:
    print("There is no occupation with data beyond the 75th percentile.")

```

    Profession with the largest share of the workforce above the 75th percentile: Priv-house-serv
    


```python
N.B. After the '?' removed from the occupation column, the dataset 'income_data' was saved as 'income_data_cleaned' which will be used for the next activities.
```


```python
# Step 12: Group by occupation and show the summary statistics of age
occupation_summary_stats = income_data_cleaned.groupby('occupation')['age'].describe()
oldest_profession = occupation_summary_stats[occupation_summary_stats['mean'] == occupation_summary_stats['mean'].max()].index[0]
print("Profession with the oldest workers on average:", oldest_profession)
highest_percentile_profession = occupation_summary_stats[occupation_summary_stats['75%'] == occupation_summary_stats['75%'].max()].index[0]
print("Profession with the largest share of the workforce above the 75th percentile:", highest_percentile_profession)
```

    Profession with the oldest workers on average: Exec-managerial
    Profession with the largest share of the workforce above the 75th percentile: Priv-house-serv
    


```python
# Summary statistics of age

occupation_summary_stats
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>mean</th>
      <th>std</th>
      <th>min</th>
      <th>25%</th>
      <th>50%</th>
      <th>75%</th>
      <th>max</th>
    </tr>
    <tr>
      <th>occupation</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Adm-clerical</th>
      <td>3770.0</td>
      <td>36.964456</td>
      <td>13.362998</td>
      <td>17.0</td>
      <td>26.0</td>
      <td>35.0</td>
      <td>46.0</td>
      <td>90.0</td>
    </tr>
    <tr>
      <th>Armed-Forces</th>
      <td>9.0</td>
      <td>30.222222</td>
      <td>8.089774</td>
      <td>23.0</td>
      <td>24.0</td>
      <td>29.0</td>
      <td>34.0</td>
      <td>46.0</td>
    </tr>
    <tr>
      <th>Craft-repair</th>
      <td>4099.0</td>
      <td>39.031471</td>
      <td>11.606436</td>
      <td>17.0</td>
      <td>30.0</td>
      <td>38.0</td>
      <td>47.0</td>
      <td>90.0</td>
    </tr>
    <tr>
      <th>Exec-managerial</th>
      <td>4066.0</td>
      <td>42.169208</td>
      <td>11.974548</td>
      <td>17.0</td>
      <td>33.0</td>
      <td>41.0</td>
      <td>50.0</td>
      <td>90.0</td>
    </tr>
    <tr>
      <th>Farming-fishing</th>
      <td>994.0</td>
      <td>41.211268</td>
      <td>15.070283</td>
      <td>17.0</td>
      <td>29.0</td>
      <td>39.0</td>
      <td>52.0</td>
      <td>90.0</td>
    </tr>
    <tr>
      <th>Handlers-cleaners</th>
      <td>1370.0</td>
      <td>32.165693</td>
      <td>12.372635</td>
      <td>17.0</td>
      <td>23.0</td>
      <td>29.0</td>
      <td>39.0</td>
      <td>90.0</td>
    </tr>
    <tr>
      <th>Machine-op-inspct</th>
      <td>2002.0</td>
      <td>37.715285</td>
      <td>12.068266</td>
      <td>17.0</td>
      <td>28.0</td>
      <td>36.0</td>
      <td>46.0</td>
      <td>90.0</td>
    </tr>
    <tr>
      <th>Other-service</th>
      <td>3295.0</td>
      <td>34.949621</td>
      <td>14.521508</td>
      <td>17.0</td>
      <td>22.0</td>
      <td>32.0</td>
      <td>45.0</td>
      <td>90.0</td>
    </tr>
    <tr>
      <th>Priv-house-serv</th>
      <td>149.0</td>
      <td>41.724832</td>
      <td>18.633688</td>
      <td>17.0</td>
      <td>24.0</td>
      <td>40.0</td>
      <td>57.0</td>
      <td>81.0</td>
    </tr>
    <tr>
      <th>Prof-specialty</th>
      <td>4140.0</td>
      <td>40.517633</td>
      <td>12.016676</td>
      <td>17.0</td>
      <td>31.0</td>
      <td>40.0</td>
      <td>48.0</td>
      <td>90.0</td>
    </tr>
    <tr>
      <th>Protective-serv</th>
      <td>649.0</td>
      <td>38.953775</td>
      <td>12.822062</td>
      <td>17.0</td>
      <td>29.0</td>
      <td>36.0</td>
      <td>47.0</td>
      <td>90.0</td>
    </tr>
    <tr>
      <th>Sales</th>
      <td>3650.0</td>
      <td>37.353973</td>
      <td>14.186352</td>
      <td>17.0</td>
      <td>25.0</td>
      <td>35.0</td>
      <td>47.0</td>
      <td>90.0</td>
    </tr>
    <tr>
      <th>Tech-support</th>
      <td>928.0</td>
      <td>37.022629</td>
      <td>11.316594</td>
      <td>17.0</td>
      <td>28.0</td>
      <td>36.0</td>
      <td>44.0</td>
      <td>73.0</td>
    </tr>
    <tr>
      <th>Transport-moving</th>
      <td>1597.0</td>
      <td>40.197871</td>
      <td>12.450792</td>
      <td>17.0</td>
      <td>30.0</td>
      <td>39.0</td>
      <td>49.0</td>
      <td>90.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Step 13: Use subset and groupby to find outliers
outliers = income_data_cleaned.groupby('occupation').apply(lambda x: x[(x['age'] < x['age'].quantile(0.25)) | (x['age'] > x['age'].quantile(0.75))])
outliers
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>age</th>
      <th>workclass</th>
      <th>fnlwgt</th>
      <th>education</th>
      <th>education-num</th>
      <th>marital-status</th>
      <th>occupation</th>
      <th>relationship</th>
      <th>sex</th>
      <th>capital-gain</th>
      <th>capital-loss</th>
      <th>hours-per-week</th>
      <th>native-country</th>
      <th>income</th>
    </tr>
    <tr>
      <th>occupation</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">Adm-clerical</th>
      <th>12</th>
      <td>23</td>
      <td>Private</td>
      <td>122272</td>
      <td>Bachelors</td>
      <td>13</td>
      <td>Never-married</td>
      <td>Adm-clerical</td>
      <td>Own-child</td>
      <td>Female</td>
      <td>0</td>
      <td>0</td>
      <td>30</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
    <tr>
      <th>37</th>
      <td>19</td>
      <td>Private</td>
      <td>544091</td>
      <td>HS-grad</td>
      <td>9</td>
      <td>Married-AF-spouse</td>
      <td>Adm-clerical</td>
      <td>Wife</td>
      <td>Female</td>
      <td>0</td>
      <td>0</td>
      <td>25</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
    <tr>
      <th>43</th>
      <td>49</td>
      <td>Private</td>
      <td>94638</td>
      <td>HS-grad</td>
      <td>9</td>
      <td>Separated</td>
      <td>Adm-clerical</td>
      <td>Unmarried</td>
      <td>Female</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
    <tr>
      <th>67</th>
      <td>53</td>
      <td>Private</td>
      <td>169846</td>
      <td>HS-grad</td>
      <td>9</td>
      <td>Married-civ-spouse</td>
      <td>Adm-clerical</td>
      <td>Wife</td>
      <td>Female</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&gt;50K</td>
    </tr>
    <tr>
      <th>126</th>
      <td>20</td>
      <td>Private</td>
      <td>111697</td>
      <td>Some-college</td>
      <td>10</td>
      <td>Never-married</td>
      <td>Adm-clerical</td>
      <td>Own-child</td>
      <td>Female</td>
      <td>0</td>
      <td>1719</td>
      <td>28</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
    <tr>
      <th>...</th>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th rowspan="5" valign="top">Transport-moving</th>
      <th>32289</th>
      <td>24</td>
      <td>Private</td>
      <td>34568</td>
      <td>Assoc-voc</td>
      <td>11</td>
      <td>Never-married</td>
      <td>Transport-moving</td>
      <td>Not-in-family</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
    <tr>
      <th>32377</th>
      <td>28</td>
      <td>Private</td>
      <td>180299</td>
      <td>HS-grad</td>
      <td>9</td>
      <td>Married-civ-spouse</td>
      <td>Transport-moving</td>
      <td>Husband</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>70</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
    <tr>
      <th>32435</th>
      <td>25</td>
      <td>Private</td>
      <td>175128</td>
      <td>HS-grad</td>
      <td>9</td>
      <td>Married-civ-spouse</td>
      <td>Transport-moving</td>
      <td>Husband</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
    <tr>
      <th>32441</th>
      <td>53</td>
      <td>Private</td>
      <td>304504</td>
      <td>Some-college</td>
      <td>10</td>
      <td>Married-civ-spouse</td>
      <td>Transport-moving</td>
      <td>Husband</td>
      <td>Male</td>
      <td>0</td>
      <td>1887</td>
      <td>45</td>
      <td>United-States</td>
      <td>&gt;50K</td>
    </tr>
    <tr>
      <th>32498</th>
      <td>57</td>
      <td>Private</td>
      <td>153918</td>
      <td>HS-grad</td>
      <td>9</td>
      <td>Married-civ-spouse</td>
      <td>Transport-moving</td>
      <td>Husband</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
  </tbody>
</table>
<p>14518 rows × 14 columns</p>
</div>




```python
# Step 14: Plot the values on a bar chart
outliers_count = outliers['occupation'].value_counts()
plt.bar(outliers_count.index, outliers_count.values)
plt.title('Outliers Count by Occupation')
plt.xlabel('Occupation')
plt.ylabel('Count')
plt.xticks(rotation=90)
plt.show()
```


    
![png](output_36_0.png)
    



```python
# Step 15: Merge the data using common keys

import pandas as pd

# Summary statistics DataFrame
occupation_summary_stats = income_data_cleaned.groupby('occupation')['age'].describe().reset_index()

# Merge the data using common keys (occupation)
merged_data = pd.merge(income_data_cleaned, occupation_summary_stats, on='occupation')

# Print the merged DataFrame
print(merged_data)

```

           age     workclass  fnlwgt      education  education-num  \
    0       39     State-gov   77516      Bachelors             13   
    1       23       Private  122272      Bachelors             13   
    2       30   Federal-gov   59951   Some-college             10   
    3       19       Private  544091        HS-grad              9   
    4       49       Private   94638        HS-grad              9   
    ...    ...           ...     ...            ...            ...   
    30713   17       Private   79682           10th              6   
    30714   27       Private  363053            9th              5   
    30715   24       Private  213902        7th-8th              4   
    30716   19       Private  188568   Some-college             10   
    30717   17       Private  141590           11th              7   
    
                marital-status       occupation     relationship      sex  \
    0            Never-married     Adm-clerical    Not-in-family     Male   
    1            Never-married     Adm-clerical        Own-child   Female   
    2       Married-civ-spouse     Adm-clerical        Own-child     Male   
    3        Married-AF-spouse     Adm-clerical             Wife   Female   
    4                Separated     Adm-clerical        Unmarried   Female   
    ...                    ...              ...              ...      ...   
    30713        Never-married  Priv-house-serv   Other-relative     Male   
    30714        Never-married  Priv-house-serv        Unmarried   Female   
    30715        Never-married  Priv-house-serv        Own-child   Female   
    30716        Never-married  Priv-house-serv    Not-in-family   Female   
    30717        Never-married  Priv-house-serv        Own-child   Female   
    
           capital-gain  ...  native-country  income   count       mean  \
    0              2174  ...   United-States   <=50K  3770.0  36.964456   
    1                 0  ...   United-States   <=50K  3770.0  36.964456   
    2                 0  ...   United-States   <=50K  3770.0  36.964456   
    3                 0  ...   United-States   <=50K  3770.0  36.964456   
    4                 0  ...   United-States   <=50K  3770.0  36.964456   
    ...             ...  ...             ...     ...     ...        ...   
    30713             0  ...   United-States   <=50K   149.0  41.724832   
    30714             0  ...          Mexico   <=50K   149.0  41.724832   
    30715             0  ...     El-Salvador   <=50K   149.0  41.724832   
    30716             0  ...   United-States   <=50K   149.0  41.724832   
    30717             0  ...   United-States   <=50K   149.0  41.724832   
    
                 std   min   25%   50%   75%   max  
    0      13.362998  17.0  26.0  35.0  46.0  90.0  
    1      13.362998  17.0  26.0  35.0  46.0  90.0  
    2      13.362998  17.0  26.0  35.0  46.0  90.0  
    3      13.362998  17.0  26.0  35.0  46.0  90.0  
    4      13.362998  17.0  26.0  35.0  46.0  90.0  
    ...          ...   ...   ...   ...   ...   ...  
    30713  18.633688  17.0  24.0  40.0  57.0  81.0  
    30714  18.633688  17.0  24.0  40.0  57.0  81.0  
    30715  18.633688  17.0  24.0  40.0  57.0  81.0  
    30716  18.633688  17.0  24.0  40.0  57.0  81.0  
    30717  18.633688  17.0  24.0  40.0  57.0  81.0  
    
    [30718 rows x 22 columns]
    

N.B. The original dataset was merged with the summary statistics DataFrame based on the 'occupation' column, adding summary statistics for each occupation to each corresponding row in the original dataset.



```python

```

# Discussion Activity 4.01


The primary objective of this analysis is to investigate the factors that influence income levels among adults. 

Specifically,the aims are:

Identify demographic attributes associated with higher income levels.
Analyze the distribution of income across different occupations.
Detect outliers in the dataset and assess their impact on the analysis.
Provide insights into potential avenues for further research and exploration.


The analysis begins with data preprocessing, including handling missing values, data cleaning, and feature selection. We then proceed to explore the dataset through descriptive statistics, visualizations, and advanced data wrangling techniques. 

Key steps in the analysis include:

Data loading and preprocessing: Reading the dataset from a CSV file, handling missing values, and cleaning the data.
Exploratory data analysis: Visualizing the distribution of demographic attributes such as age, education, and occupation.
Statistical analysis: Calculating summary statistics, identifying outliers, and assessing their impact on the analysis.
Comparative analysis: Comparing income levels across different demographic groups and occupations.
Interpretation and discussion: Interpreting the findings, discussing insights gained from the analysis, and proposing future research directions.


The analysis reveals several noteworthy insights into the factors influencing income levels among adults. Education emerges as a significant predictor of income, with higher education levels corresponding to higher median incomes. Additionally, certain occupations, particularly those in managerial and professional fields, tend to command higher salaries. However, the presence of outliers suggests the need for cautious interpretation, as extreme values may distort the overall analysis. Furthermore, age exhibits a complex relationship with income, indicating potential nonlinear effects that merit deeper exploration.

# Excercise 3


```python
# Import required library
import pandas as pd
```


```python
# Creating Series 1
data1 = [7.3, -2.5, 3.4, 1.5]
index1 = ['a', 'c', 'd', 'e']
series1 = pd.Series(data1, index=index1)
```


```python
# Creating Series 2
data2 = [-2.1, 3.6, -1.5, 4, 3.1]
index2 = ['a', 'c', 'e', 'f', 'g']
series2 = pd.Series(data2, index=index2)
```


```python
# Adding Series 1 and Series 2
addition_result = series1.add(series2, fill_value=0)
print("Addition Result:")
print(addition_result)
```

    Addition Result:
    a    5.2
    c    1.1
    d    3.4
    e    0.0
    f    4.0
    g    3.1
    dtype: float64
    


```python
# Subtracting Series 1 from Series 2
subtraction_result = series2.subtract(series1, fill_value=0)
print("\nSubtraction Result:")
print(subtraction_result)
```

    
    Subtraction Result:
    a   -9.4
    c    6.1
    d   -3.4
    e   -3.0
    f    4.0
    g    3.1
    dtype: float64
    

# Discussion Excercise 3


The task at hand involves creating two pandas Series objects, each with specified data and index values, and performing addition and subtraction operations on them. Additionally, the aim was to investigate how the operations handle missing indices and data points, and discuss the implications of these behaviors.

Data Preparation: Two pandas Series objects, Series 1 and Series 2, are created with specified data and index values.
Arithmetic Operations: Addition and subtraction operations are performed on Series 1 and Series 2.
Handling Missing Values: The operations are executed with the consideration of missing indices or data points using the fill_value=0 argument.

The addition operation combines corresponding elements from both Series, resulting in a new Series with the union of indices from both input Series. Any missing index or data point is treated as zero during the operation. Similarly, the subtraction operation computes the difference between corresponding elements of the Series, also considering missing values as zero.


# Short Report on Overall activities


Title: Exploratory Analysis of Diverse Datasets: Insights and Methodologies

Introduction: This comprehensive report integrates findings from three distinct analyses: an exploratory data analysis (EDA) of the Boston Housing Dataset, an analysis of the Adult Income Dataset, and an investigation into arithmetic operations on pandas Series in Python. The aim is to synthesize key insights and methodologies from these analyses to provide a comprehensive understanding of data exploration, analysis, and manipulation techniques.

Statement of the Problem: The overarching objective of this report is to explore diverse datasets, ranging from housing attributes to demographic information and computational operations, to uncover patterns, relationships, and implications for further research and decision-making. Specifically, the analyses aim to:

Explore factors influencing housing prices in the Boston area. Identify demographic and occupational determinants of income levels among adults. Investigate the implementation and implications of basic arithmetic operations on pandas Series.

Methodology: The methodologies employed in each analysis vary based on the nature of the dataset and the objectives of the investigation.

Boston Housing Dataset Analysis: The analysis begins with data loading and preprocessing using pandas. Descriptive statistics, visualizations (such as histograms and scatter plots), and correlation analyses are conducted to explore relationships between variables. The methodology emphasizes data wrangling, visualization, and statistical analysis.

Adult Income Dataset Analysis: Data preprocessing involves handling missing values and feature selection. Descriptive statistics, visualizations, and statistical analysis are employed to identify patterns and relationships between demographic attributes, occupations, and income levels. Comparative analysis is used to compare income levels across different demographic groups and occupations.

Arithmetic Operations on Pandas Series: Two pandas Series objects are created, and addition and subtraction operations are performed. The analysis investigates how these operations handle missing values using the fill_value=0 argument.

Result and Discussion

Boston Housing Dataset:
Total number of records: 506
Mean Rooms per Dwelling: 6.28
Median Age: 77.5
Mean Distance to Employment Centers: 3.80
Percentage of Houses with Low Price (< $20,000): 41.50%
Insights from the Boston Housing Dataset provide valuable information about the housing market in the area. The distribution of housing prices indicates a significant proportion of affordable housing options, with 41.50% of houses priced below $20,000. Additionally, variables such as the number of rooms per dwelling and distance to employment centers offer insights into factors influencing property prices. Correlations between variables, such as crime rate and property prices, further contribute to understanding housing dynamics in the area.

Adult Income Dataset:
Number of people aged between 30 and 50: 16,390
Profession with the oldest workers on average: Exec-managerial
Profession with the largest share of the workforce above the 75th percentile: Priv-house-serv
Analysis of the Adult Income Dataset highlights the significance of demographic attributes such as age, education, and occupation in determining income levels among adults. With 16,390 people aged between 30 and 50, the dataset provides insights into the demographic composition of the workforce. The identification of professions with the oldest workers on average, such as Exec-managerial, and those with the largest share of the workforce above the 75th percentile, such as Priv-house-serv, offers valuable insights for workforce planning and labor market analysis.

Arithmetic Operations on Pandas Series:
The practical implementation of addition and subtraction operations on pandas Series provides a foundational understanding of data manipulation techniques. Considerations for handling missing values, as demonstrated in the arithmetic operations, are crucial for accurate data analysis. These operations serve as building blocks for more complex data manipulations and analyses in diverse domains.

Conclusions:
The comprehensive analysis of diverse datasets, including the Boston Housing Dataset and the Adult Income Dataset, offers valuable insights into housing dynamics, workforce demographics, and data manipulation techniques. Understanding factors influencing housing prices and income levels, as well as implementing basic arithmetic operations on pandas Series, contributes to informed decision-making and further research in related domains. The findings from these analyses lay the groundwork for exploring complex relationships within datasets and informing future research directions.


Way Forward: Moving forward, future research could involve more advanced analyses, predictive modeling, and exploration of alternative methodologies. Additionally, continued investigation into the datasets and techniques discussed in this report could lead to deeper insights and practical applications in various fields, including urban planning, socioeconomic research, and data analysis.


```python

```
